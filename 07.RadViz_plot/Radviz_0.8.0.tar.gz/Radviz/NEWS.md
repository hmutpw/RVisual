# 2019-12-18

Radviz now uses ggplot2 for plotting, enabling richer options for labeling and statistics.