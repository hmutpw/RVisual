#' @rdname Radviz-deprecated
#' @export
do.density <- function(x,...) {
  .Defunct(new='contour.radviz',
           msg='the do.density function is not required anymore, use contour.radviz directly')
  return(x)
}
